
document.onload = function() {
    alert("Hello!");
};